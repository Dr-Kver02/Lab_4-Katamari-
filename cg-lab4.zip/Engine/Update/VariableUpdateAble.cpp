﻿#include "VariableUpdateAble.h"

using namespace engine::update;

void VariableUpdateAble::Compose(VariableUpdate* variable_update)
{
    variable_update_ = variable_update;
}
