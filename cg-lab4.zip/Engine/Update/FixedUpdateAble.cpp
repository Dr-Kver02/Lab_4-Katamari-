﻿#include "FixedUpdateAble.h"

using namespace engine::update;

void FixedUpdateAble::Compose(update::FixedUpdate* fixed_update)
{
}

void FixedUpdateAble::FixedUpdate()
{
}
