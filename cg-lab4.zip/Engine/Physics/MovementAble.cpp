﻿#include "MovementAble.h"

using namespace engine::physics;

void MovementAble::Compose(Movement* movement)
{
}
