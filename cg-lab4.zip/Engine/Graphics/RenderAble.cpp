﻿#include "RenderAble.h"

using namespace engine::graphics;

void RenderAble::Compose(RenderPipeline* pipeline)
{
    pipeline_ = pipeline;
}
