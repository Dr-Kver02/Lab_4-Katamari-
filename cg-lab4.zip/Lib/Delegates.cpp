#include "Delegates.h"

unsigned int Lib::DelegateHandle::CURRENT_ID = 0;
